import { Link } from "react-router-dom";

function Home() {
  return (
    <main className="page-container">
      <section className="hero">
        <span className="eyebrow">DCIT 26 • Laboratory Exercise 3</span>
        <h1>React Routing Student Portal</h1>
        <p>
          This activity demonstrates static and dynamic routing using React Router DOM,
          reusable components, and student data stored in JSON.
        </p>
        <Link className="button-link hero-button" to="/students">
          View Students
        </Link>
      </section>
    </main>
  );
}

export default Home;
