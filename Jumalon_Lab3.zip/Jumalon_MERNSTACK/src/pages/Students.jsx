import Student from "../components/Student";
import students from "../data/students.json";

function Students() {
  return (
    <main className="page-container">
      <section className="page-heading">
        <span className="eyebrow">Student Directory</span>
        <h1>Students</h1>
        <p>Select a student card to view the complete student information.</p>
      </section>

      <section className="student-grid" aria-label="Student list">
        {students.map((student) => (
          <Student key={student.id} student={student} />
        ))}
      </section>
    </main>
  );
}

export default Students;
