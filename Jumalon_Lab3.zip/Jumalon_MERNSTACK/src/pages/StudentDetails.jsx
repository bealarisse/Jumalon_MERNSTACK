import { Link, useParams } from "react-router-dom";
import students from "../data/students.json";

function StudentDetails() {
  const { id } = useParams();
  const student = students.find((item) => item.id === parseInt(id, 10));

  if (!student) {
    return (
      <main className="page-container">
        <section className="details-card not-found">
          <h1>Student Not Found</h1>
          <p>No student matches the selected ID.</p>
          <Link className="button-link" to="/students">
            Back to Students
          </Link>
        </section>
      </main>
    );
  }

  return (
    <main className="page-container">
      <section className="details-card">
        <Link className="back-link" to="/students">
          ← Back to Students
        </Link>

        <div className="details-header">
          <div className="student-avatar large" aria-hidden="true">
            {student.name.charAt(0).toUpperCase()}
          </div>
          <div>
            <span className="eyebrow">Student Details</span>
            <h1>{student.name}</h1>
            <p>{student.studentnumber}</p>
          </div>
        </div>

        <div className="details-grid">
          <div className="detail-item">
            <span>Age</span>
            <strong>{student.age}</strong>
          </div>
          <div className="detail-item">
            <span>Section</span>
            <strong>{student.section}</strong>
          </div>
          <div className="detail-item">
            <span>Course</span>
            <strong>{student.course}</strong>
          </div>
          <div className="detail-item">
            <span>Student Number</span>
            <strong>{student.studentnumber}</strong>
          </div>
        </div>
      </section>
    </main>
  );
}

export default StudentDetails;
