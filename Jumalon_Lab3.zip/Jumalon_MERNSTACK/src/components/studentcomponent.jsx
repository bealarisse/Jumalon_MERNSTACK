export { default } from "./Student";
