import { Link, NavLink } from "react-router-dom";

function Navbar() {
  return (
    <header className="navbar">
      <div className="nav-container">
        <Link className="brand" to="/">
          Student Portal
        </Link>

        <nav className="nav-links" aria-label="Main navigation">
          <NavLink
            to="/"
            end
            className={({ isActive }) => (isActive ? "nav-link active" : "nav-link")}
          >
            Home
          </NavLink>
          <NavLink
            to="/students"
            className={({ isActive }) => (isActive ? "nav-link active" : "nav-link")}
          >
            Students
          </NavLink>
        </nav>
      </div>
    </header>
  );
}

export default Navbar;
